public class CrazyEightsDriver{
  public static void main(String[] args){
    
  }
}
